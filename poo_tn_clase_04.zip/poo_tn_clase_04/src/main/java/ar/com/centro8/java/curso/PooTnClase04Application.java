package ar.com.centro8.java.curso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooTnClase04Application {

	public static void main(String[] args) {
		SpringApplication.run(PooTnClase04Application.class, args);
	}

}
