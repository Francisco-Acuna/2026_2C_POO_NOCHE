package ar.com.centro8.java.curso;

public class TestClass {
    public static void main(String[] args) {
        
        //creamos un objeto de la clase Auto
        Auto auto1 = new Auto();
        // un objeto es una instancia de una clase, es decir, una entidad con 
        // características (atributos) y comportamiento (métodos)

        // le damos estado al objeto (dar estado es completar el valor de sus atributos)
        auto1.marca = "Fiat";
        auto1.modelo = "Cronos";
        auto1.color = "Blanco";
        auto1.velocidad = 0;

        // vemos el valor de sus atributos
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);

    }
}
