package ar.com.centro8.java.curso;

public class Auto {
    // una clase es una plantilla o molde que define los atributos y métodos que tendrán los objetos.

    // atributos de la clase
    // definimos los atributos o propiedades (son variables que indican las características)
    String marca;
    String modelo;
    String color;
    int velocidad;


    // métodos
    // definimos los métodos (son bloques de código que definen el comportamiento del objeto → acciones)

    void acelerar(){
        velocidad += 10;
    }
    // un procedimiento puede recibir o no, parámetros. No retorna nada. En su declaración debe llevar la palabra
    //reservada void

    void frenar(){
        velocidad -= 10;
    }

}
