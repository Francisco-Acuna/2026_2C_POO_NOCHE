package ar.com.centro8.java.curso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooTnClase04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
