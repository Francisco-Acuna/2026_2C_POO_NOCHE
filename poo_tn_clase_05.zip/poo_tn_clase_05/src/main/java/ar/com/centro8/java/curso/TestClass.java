package ar.com.centro8.java.curso;

public class TestClass {
    public static void main(String[] args) {
        
        //creamos un objeto de la clase Auto
        Auto auto1 = new Auto();
        // un objeto es una instancia de una clase, es decir, una entidad con 
        // características (atributos) y comportamiento (métodos)

        // le damos estado al objeto (dar estado es completar el valor de sus atributos)
        auto1.marca = "Fiat";
        auto1.modelo = "Cronos";
        auto1.color = "Blanco";
        auto1.velocidad = 0;

        // vemos el valor de sus atributos
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);

        // utilizamos los métodos
        auto1.acelerar();
        System.out.println(auto1.velocidad);
        auto1.frenar();
        System.out.println(auto1.velocidad);

        //creamos otro objeto
        Auto auto2 = new Auto();
        auto2.marca = "Audi";
        auto2.modelo = "A4";
        auto2.color = "Negro y rosa";
        auto2.velocidad = 0;

        System.out.println("El auto es un " + auto2.marca + ", modelo " + auto2.modelo + " de color " + auto2.color
            + " y tiene una velocidad de " + auto2.velocidad + "kms. x hora"
        );

        for(int i=0; i<5; i++) auto2.acelerar();
        auto2.imprimirVelocidad();

        auto2.acelerar(20);
        auto2.acelerar(15, true);
        System.out.println(auto2.obtenerVelocidad());

        // Método toString()
        // El método toString() es un método heredado de la clase Object, por lo tanto está presente en todas las clases.
        // Su función es representar al objeto en forma de una cadena (String)
        System.out.println(auto2.toString());
        // por defecto, devuelve una cadena con la ruta, el nombre de la clase y un @ seguido del código hash
        // en formato hexadecimal
        
        

    }
}
