package ar.com.centro8.java.curso;

public class Auto {
    // una clase es una plantilla o molde que define los atributos y métodos que tendrán los objetos.

    // atributos de la clase
    // definimos los atributos o propiedades (son variables que indican las características)
    String marca;
    String modelo;
    String color;
    int velocidad;

    // constructores
    // Si no definimos un constructor, se crea uno vacío por defecto.
    // Los métodos constructores tienen el mismo nombre de la clase y llevan paréntesis.

    // Constructor vacío (no lleva parámetros)
    Auto(){}

    // Constructor completo (lleva todos los atributos como parámetros)
    Auto(String marca, String modelo, String color, int velocidad){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    // Sobrecarga de constructores
    Auto(String marca, String modelo, String color){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    // Constructor de la marca Ford
    Auto(String modelo, String color){
        this.marca = "Ford";
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;

    }

    // métodos
    // definimos los métodos (son bloques de código que definen el comportamiento del objeto → acciones)

    void acelerar(){
        velocidad += 10;
    }
    // un procedimiento puede recibir o no, parámetros. No retorna nada. En su declaración debe llevar la palabra
    //reservada void

    void frenar(){
        velocidad -= 10;
    }

    // sobrecarga de métodos

    void acelerar(int kilometros){
        velocidad += kilometros;
    }

    /**
     * Si el turbo es true, incrementa el doble de kilómetros.
     * @param kilometros → cantidad de kilómetros que va a aumentar la velocidad
     * @param turbo → si es true, incrementa el doble
     */
    void acelerar(int kilometros, boolean turbo){
        if(turbo){
            velocidad += kilometros*2;
        }else{
            velocidad += kilometros;
        }
    }

    void frenar(int kilometros){
        if(velocidad - kilometros < 0){
            velocidad = 0;
        }else{
            velocidad -= kilometros;
        }
    }

    void imprimirVelocidad(){
        System.out.println(velocidad);
    } //procedimiento

    int obtenerVelocidad(){
        return velocidad;
    }//función

    @Override
    public String toString(){
        return "El auto es un " + marca + ", modelo " + modelo + " de color " + color
            + " y tiene una velocidad de " + velocidad + "kms. x hora";
    }

}
