public class Clase01 {

    public static void main(String[] args) {
        
        /*
        Instituto: Centro de Formación Profesional N°8
        Curso: Programación Orientada a Objetos
        Lenguaje: Java
        Cursada: lunes, miércoles y viernes de 19 a 22.30hs
        Profesor: Francisco Acuña
        Email: franciscoacuna.centro8@gmail.com
        Redes: F/IG franacuna.tech
        Repositorio: https://github.com/Francisco-Acuna/2026_2C_POO_MANIANA_TN
        Softwares necesarios:
            - JDK (sugerido 25 LTS) → https://www.oracle.com/java/technologies/downloads/#jdk25-windows
            - Visual Studio Code → https://code.visualstudio.com/
            - Extensión de VSC → Extension Pack For Java (By Microsoft)
            - MySQL y Workbench → https://dev.mysql.com/downloads/installer
        */

        // comentarios en línea

        /*
        comentario en bloque
        se puede escribir
        en varias líneas
        */

        /**
         * Comentarios del tipo 
         * JavaDoc
         * Son en bloque y permiten documentar bloques de código.
         */

        // Etiquetas en comentarios:

        // TODO indica tareas pendientes por implementar o finalizar

        // FIXME indica errores o problemas que deben ser corregidos

        // Instalar Better Todo Tree de Fanatic Pythoner

        // Imprimir en consola
        System.out.println("Hola Mundo!");
        // atajo de teclado
        // sout + tab
        System.out.println();

        // declaración de variable:
        int variable; //declaración de variable con el tipo de dato y el identificador.
        variable = 10; // asignación de valor a la variable
        int variable2 = 10; //declaración y asignación en línea
        variable = 20;
        // variable = "diez"; ERROR, debo respetar el tipo de dato de la variable.
        // float variable; ERROR no se puede cambiar el tipo de dato a una variable
        // int variable; ERROR no se puede volver a declarar una variable dos veces
        int variable3=10, variable4=20, variable5=30; // declaración y asignación múltiple en línea

        /*
            Java es un lenguaje fuertemente tipado, por lo cual se deben respetar ciertos puntos.
            - No se puede asignar otro tipo de dato como valor a una variable ya declarada.
            - No puedo cambiar el tipo de dato de una variable ya declarada.
            - No puedo crear otra variable con el mismo nombre.
            - Una variable puede tener una única declaración.
            - Una variable puede tener innumerables valores, siempre del mismo tipo de dato.
        */
        

    }
}