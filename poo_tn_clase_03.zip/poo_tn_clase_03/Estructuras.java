import java.util.Scanner;

public class Estructuras {
    public static void main(String[] args) {
        
        //Estructuras

        //Condicionales

        // if
        int numero1 = 10;
        int numero2 = 20;

        if(numero1 > numero2){
            System.out.println("El número 1 es mayor que el número 2");
        }

        if(numero1 < numero2) System.out.println("El número 1 es menor que el número 2");
        //podemos escribir el if en línea cuando solo hay una única instrucción dentro del if

        // if-else
        if(numero1 > numero2){
            System.out.println("El número 1 es mayor que el número 2");
        } else{
            System.out.println("El número 1 no es mayor que el número 2");
        }

        if(numero1 > numero2) System.out.println("El número 1 es mayor que el número 2");
        else System.out.println("El número 1 no es mayor que el número 2");
        // si solo hay una instrucción en el if o en el else, los podemos escribir en línea.

        // if-else en cascada (if-else if-else)
        if(numero1 > numero2){
            System.out.println("El número 1 es mayor que el número 2");
        } else if(numero1 < numero2){
            System.out.println("El número 1 no es mayor que el número 2");
        } else {
            System.out.println("Los dos números son iguales.");
        }

        // if-else anidado
        int edad = 20;
        boolean tienePasaporte = false;

        if(tienePasaporte){
            if (edad >= 18) {
                System.out.println("Puede viajar solo");
            } else {
                System.out.println("Puede viajar, pero acompañado de un mayor");
            }
        } else {
            System.out.println("No puede viajar.");
        }

        // Operador ternario (if-else abreviado)
        // condición ? valorSiVerdadero : valorSiFalso;

        String mensaje = (edad >= 18) ? "Es mayor de edad" : "No es mayor de edad";
        System.out.println(mensaje);

        // Estructura switch
        int dia = 5;

        switch (dia){
            case 1: System.out.println("Hoy es lunes"); break;
            case 2: System.out.println("Hoy es martes"); break;
            case 3: System.out.println("Hoy es miércoles"); break;
            case 4: System.out.println("Hoy es jueves"); break;
            case 5: System.out.println("Hoy es viernes"); break;
            case 6: System.out.println("Hoy es sábado"); break;
            case 7: System.out.println("Hoy es domingo"); break;
            default: System.out.println("No es un día válido");
        }
        //el default no es obligatorio en el switch case tradicional

        switch (dia){
            case 1, 2, 3, 4, 5: System.out.println("Es un día de semana."); break;
            case 6, 7: System.out.println("Es fin de semana");
        }

        // rule switch (JDK 14)
        // se reemplazan los : por las -> 
        // desaparecen los break
        // de puede utilizar como una expresión

        String diaSemana = switch(dia){
            case 1 -> "Lunes";
            case 2 -> "Martes";
            case 3 -> "Miércoles";
            case 4 -> "Jueves";
            case 5 -> "Viernes";
            case 6 -> "Sábado";
            case 7 -> "Domingo";
            default -> "Día inválido";
        };
        // En las rule switch es obligatorio poner el default, por si no se encuentra coincidencia con el valor de la variable
        System.out.println(diaSemana);


        // Estructuras repetitivas:

        //while 
        int contador = 1;

        while(contador <= 10){
            System.out.println(contador);
            contador++;
        }
        System.out.println();
        System.out.println("El valor de contador es: " + contador);


        //do-while con break y continue
        int numero = 0;
        int suma = 0;
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese su nombre:");
        String nombre = sc.nextLine();
        System.out.println("Hola " + nombre);

        System.out.println("Se sumarán los números enteros, pares, positivos.");
        System.out.println("Siempre y cuando la suma no supere los 100");
        do{
            System.out.println("Ingrese un número para sumar o un 0 para salir:");
            numero = sc.nextInt();
            if(numero %2 != 0) continue; //corta la secuencia e inicia desde el principio
            if(numero>0) suma += numero; // acumula la suma de números en la variable suma
            if(suma > 100) break; // corta la secuencia de comandos y lo saca de la estructura
        } while(numero != 0);
        System.out.println("La suma de los números positivos enteros es de: " + suma);

        // for
        for (int i = 0; i <= 10; i++) {
            System.out.println(i);
        }


    }
}
