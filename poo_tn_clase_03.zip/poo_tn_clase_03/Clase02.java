public class Clase02 {

    public static void main(String[] args) {
        
        /*
        Instituto: Centro de Formación Profesional N°8
        Curso: Programación Orientada a Objetos
        Lenguaje: Java
        Cursada: lunes, miércoles y viernes de 19 a 22.30hs
        Profesor: Francisco Acuña
        Email: franciscoacuna.centro8@gmail.com
        Redes: F/IG franacuna.tech
        Repositorio: https://github.com/Francisco-Acuna/2026_2C_POO_MANIANA_TN
        Softwares necesarios:
            - JDK (sugerido 25 LTS) → https://www.oracle.com/java/technologies/downloads/#jdk25-windows
            - Visual Studio Code → https://code.visualstudio.com/
            - Extensión de VSC → Extension Pack For Java (By Microsoft)
            - MySQL y Workbench → https://dev.mysql.com/downloads/installer
        */

        // comentarios en línea

        /*
        comentario en bloque
        se puede escribir
        en varias líneas
        */

        /**
         * Comentarios del tipo 
         * JavaDoc
         * Son en bloque y permiten documentar bloques de código.
         */

        // Etiquetas en comentarios:

        // TODO indica tareas pendientes por implementar o finalizar

        // FIXME indica errores o problemas que deben ser corregidos

        // Instalar Better Todo Tree de Fanatic Pythoner

        // Imprimir en consola
        System.out.println("Hola Mundo!");
        // atajo de teclado
        // sout + tab
        System.out.println();

        // declaración de variable:
        int variable; //declaración de variable con el tipo de dato y el identificador.
        variable = 10; // asignación de valor a la variable
        int variable2 = 10; //declaración y asignación en línea
        variable = 20;
        // variable = "diez"; ERROR, debo respetar el tipo de dato de la variable.
        // float variable; ERROR no se puede cambiar el tipo de dato a una variable
        // int variable; ERROR no se puede volver a declarar una variable dos veces
        int variable3=10, variable4=20, variable5=30; // declaración y asignación múltiple en línea

        /*
            Java es un lenguaje fuertemente tipado, por lo cual se deben respetar ciertos puntos.
            - No se puede asignar otro tipo de dato como valor a una variable ya declarada.
            - No puedo cambiar el tipo de dato de una variable ya declarada.
            - No puedo crear otra variable con el mismo nombre.
            - Una variable puede tener una única declaración.
            - Una variable puede tener innumerables valores, siempre del mismo tipo de dato.
        */

        // ** Tipos de datos primitivos **

        // byte - ocupa 1 bytes y representa un número entero entre -128 y 127
        byte variableByte = 100;
        System.out.println(variableByte);
        // byte variableByte2 = 128; ERROR - excede la capacidad máxima del tipo de dato

        // short - ocupa 2 bytes y representa un número entero entre -32.768 y 32.767
        short variableShort = 30125;
        System.out.println(variableShort);

        // int - ocupa 4 bytes y representa un número entero entre -2.147.483.648 y 2.147.483.647
        // es el más utilizado, por defecto
        int variableInt = 2105356987;
        System.out.println(variableInt);

        // long - ocupa 8 bytes y representa un número entero muy grande que va desde -2 elevado a la 63
        // hasta 2 elevado a la 63, menos 1
        long variableLong = 16548465468498L;
        System.out.println(variableLong);
        // las variables del tipo long deben llevar una letra L al final de su literal
        // utilizamos por convención la L mayúscula porque la l minúscula parece un 1

        /*
        Tipos de escritura:
        estoEsUnaFraseEnCamelCase (lo utilizamos para variables, atributos y métodos)
        EstoEsUnaFraseEnPascalCase (lo utilizamos para clases e interfaces)
        esto_es_una_frase_en_snake_case (se suele utilizar para bases de datos)
        esto-es-una-frase-en-kebab-case (se suele utilizar para nombrar carpetas)
        */

        // float - ocupa 4 bytes y tiene alrededor de 6-7 dígitos de precisión total
        float variableFloat = 243.23f;
        System.out.println(variableFloat);
        // los tipos de datos float deben llevar una f al final de la literal

        // double - ocupa 8 bytes y tiene alrededor de 15-16 dígitos de precisión total
        double variableDouble = 243.23;
        System.out.println(variableDouble);

        // boolean - almacena solo dos valores posibles (true y false)
        boolean variableBoolean = true;
        System.out.println(variableBoolean);

        // char - ocupa 2 bytes y almacena un número entero que representa un caracter de la tabla unicode
        // unicode es un estándar de codificación de caracteres a nivel mundial
        char variableChar = 65;
        System.out.println(variableChar); // A
        variableChar += 32;
        System.out.println(variableChar); // a
        variableChar = 'C';
        System.out.println(variableChar);
        // también se puede almacenar el caracter directamente, se debe encerrar entre comillas simples

        // ** String **
        // No es un tipo de dato primitivo.
        // Representa una cadena de caracteres.
        String variableString = "Hola";
        System.out.println(variableString);

        //Concatenación de cadenas

        //operador de concatenación +
        String nombre = "Francisco";
        System.out.println("Hola " + nombre); 

        // método String.format()
        // Permite formatear cadenas
        int edad = 24;
        String mensaje = String.format("Hola, mi nombre es %s, y mi edad es %d años.", nombre, edad);
        System.out.println(mensaje);
        /*
        usa los siguientes marcadores de posición:
        %s → cadenas de texto
        %d → números enteros
        %f → números con decimales
        %n → salto de línea
        */
        
        // método System.out.printf()
        // Se utiliza para imprimir directamente con formato
        System.out.printf("Hola, mi nombre es %s, y mi edad es %d años.", nombre, edad);

        System.out.println();

        // ** Operadores

        // Operadores aritméticos
        /*
        +   suma
        -   resta
        *   multiplicación
        /   división
        %   módulo o resto de la división
        Son operadores binarios porque necesitan de 2 operandos.
        Los operandos son numéricos y el resultado es numérico.
        */

        // Operadores de asignación
        /*
        =   asignación
        +=  suma y asignación
        -=  resta y asignacion
        *=  multiplicación y asignación
        /=  división y asignación
        %=  módulo y asignación
        Son operadores binarios.
        Asignan el valor a una variable y se la modifican utilizando una expresión.
        */

        // Operadores incrementales y decrementales
        /*
        ++  incremento en 1
        --  decremento en 1
        Pueden utilizarse de dos formas:
        Prefijo (++x o --x): la variable se modifica antes de que se use su valor en la expresión.
        Postfijo (x++ o x--): la variable se modifica después de que se use su valor en la expresión.
        Son operadores unarios, trabajan con un solo operando.
        */

        // Operadores relacionales
        /*
        >   mayor
        <   menor
        >=  mayor o igual
        <=  menor o igual
        ==  igual
        !=  distinto
        Son operadores binarios.
        Los operandos son numéricos y el resultado es booleano.
        */

        // Operadores lógicos
        /*
        &   AND
        |   OR
        !   NOT (negación)
        Los operandos son booleanos.
        El resultado es booleano.
        */

        /*
        X   Y   AND   OR
        V   V   V     V
        V   F   F     V
        F   V   F     V
        F   F   F     F
        */

        /*
        Un solo operador lógico & o | evalúa ambas condiciones.
        Al utilizar dos && o || si con una condición determina el valor de verdad, no evalúa la condición que sigue.
        */

        

    }
}