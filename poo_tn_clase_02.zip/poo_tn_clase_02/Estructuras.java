public class Estructuras {
    public static void main(String[] args) {
        
        //Estructuras

        //Condicionales

        // if
        int numero1 = 10;
        int numero2 = 20;

        if(numero1 > numero2){
            System.out.println("El número 1 es mayor que el número 2");
        }

        if(numero1 < numero2) System.out.println("El número 1 es menor que el número 2");
        //podemos escribir el if en línea cuando solo hay una única instrucción dentro del if

        // if-else
        if(numero1 > numero2){
            System.out.println("El número 1 es mayor que el número 2");
        } else{
            System.out.println("El número 1 no es mayor que el número 2");
        }

        if(numero1 > numero2) System.out.println("El número 1 es mayor que el número 2");
        else System.out.println("El número 1 no es mayor que el número 2");
        // si solo hay una instrucción en el if o en el else, los podemos escribir en línea.

        // if-else en cascada (if-else if-else)
        if(numero1 > numero2){
            System.out.println("El número 1 es mayor que el número 2");
        } else if(numero1 < numero2){
            System.out.println("El número 1 no es mayor que el número 2");
        } else {
            System.out.println("Los dos números son iguales.");
        }

        // if-else anidado
        int edad = 20;
        boolean tienePasaporte = false;

        if(tienePasaporte){
            if (edad >= 18) {
                System.out.println("Puede viajar solo");
            } else {
                System.out.println("Puede viajar, pero acompañado de un mayor");
            }
        } else {
            System.out.println("No puede viajar.");
        }


    }
}
